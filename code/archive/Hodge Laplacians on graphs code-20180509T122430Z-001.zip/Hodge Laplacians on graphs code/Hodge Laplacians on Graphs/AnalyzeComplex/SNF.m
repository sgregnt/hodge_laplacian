function [SNFForm]=SNF(A)
SNFForm=reduce(A,1);
end